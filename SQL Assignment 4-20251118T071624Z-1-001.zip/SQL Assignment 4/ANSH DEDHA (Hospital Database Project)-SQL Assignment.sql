CREATE DATABASE HospitalDB;
USE HospitalDB;

CREATE TABLE Patients (
    Patient_ID INT PRIMARY KEY AUTO_INCREMENT,
    First_Name VARCHAR(50),
    Last_Name VARCHAR(50),
    Gender ENUM('Male','Female','Other'),
    DOB DATE,
    Phone VARCHAR(15),
    Address VARCHAR(100)
);
CREATE TABLE Doctors (
    Doctor_ID INT PRIMARY KEY AUTO_INCREMENT,
    First_Name VARCHAR(50),
    Last_Name VARCHAR(50),
    Department_ID INT,
    Specialization VARCHAR(50),
    Phone VARCHAR(15),
    Email VARCHAR(50),
    FOREIGN KEY (Department_ID) REFERENCES Departments(Department_ID)
);

CREATE TABLE Departments (
    Department_ID INT PRIMARY KEY AUTO_INCREMENT,
    Department_Name VARCHAR(50),
    Location VARCHAR(50)
);
CREATE TABLE Appointments (
    Appointment_ID INT PRIMARY KEY AUTO_INCREMENT,
    Patient_ID INT,
    Doctor_ID INT,
    Appointment_Date DATE,
    Appointment_Time TIME,
    Status ENUM('Scheduled','Completed','Cancelled'),
    FOREIGN KEY (Patient_ID) REFERENCES Patients(Patient_ID),
    FOREIGN KEY (Doctor_ID) REFERENCES Doctors(Doctor_ID)
);
CREATE TABLE Billing (
    Bill_ID INT PRIMARY KEY AUTO_INCREMENT,
    Patient_ID INT,
    Appointment_ID INT,
    Amount DECIMAL(10,2),
    Payment_Status ENUM('Paid','Unpaid','Pending'),
    Bill_Date DATE,
    FOREIGN KEY (Patient_ID) REFERENCES Patients(Patient_ID),
    FOREIGN KEY (Appointment_ID) REFERENCES Appointments(Appointment_ID)
);
INSERT INTO Departments (Department_Name, Location) VALUES
('Cardiology', 'Building A'),
('Neurology', 'Building B'),
('Orthopedics', 'Building C');

INSERT INTO Doctors (First_Name, Last_Name, Department_ID, Specialization, Phone, Email) VALUES
('Amit', 'Sharma', 1, 'Cardiologist', '9876543210', 'amit@hospital.com'),
('Priya', 'Singh', 2, 'Neurologist', '9876543221', 'priya@hospital.com'),
('Rohit', 'Patel', 3, 'Orthopedic', '9876543232', 'rohit@hospital.com');

INSERT INTO Patients (First_Name, Last_Name, Gender, DOB, Phone, Address) VALUES
('Raj', 'Verma', 'Male', '1995-05-12', '9998887776', 'Delhi'),
('Neha', 'Gupta', 'Female', '2000-09-22', '9998887777', 'Mumbai');

INSERT INTO Appointments (Patient_ID, Doctor_ID, Appointment_Date, Appointment_Time, Status) VALUES
(1, 1, '2025-11-10', '10:30:00', 'Scheduled'),
(2, 2, '2025-11-11', '11:00:00', 'Scheduled');

INSERT INTO Billing (Patient_ID, Appointment_ID, Amount, Payment_Status, Bill_Date) VALUES
(1, 1, 1200.50, 'Paid', '2025-11-10'),
(2, 2, 1800.00, 'Unpaid', '2025-11-11');

SELECT dept.Department_Name, COUNT(a.Patient_ID) AS Total_Patients
FROM Departments dept
JOIN Doctors doc ON dept.Department_ID = doc.Department_ID
JOIN Appointments a ON doc.Doctor_ID = a.Doctor_ID
GROUP BY dept.Department_Name;

SELECT p.First_Name, b.Amount, b.Payment_Status
FROM Billing b
JOIN Patients p ON b.Patient_ID = p.Patient_ID
WHERE b.Payment_Status = 'Unpaid';

